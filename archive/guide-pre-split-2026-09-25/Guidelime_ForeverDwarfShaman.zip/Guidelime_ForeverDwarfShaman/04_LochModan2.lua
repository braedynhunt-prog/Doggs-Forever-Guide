Guidelime.registerGuide([[
[N 16-17 Loch Modan]
[D Forever Dwarf Shaman 1-20 (Braedyn)\\Loch Modan second pass: the excavation chain, the idols, Farstrider hand-ins, and the group quests if your friend is on.]
[GA Alliance]
[OC]|cffffffffLoch Modan 16-17|r
[OC]|cffffcc00Carry-over log:|r Powder to Ironband (302), Ironband's Excavation (436), A Hunter's Challenge (258), Crocolisk Hunting (385), Twisting the Knife (86758), In Defense of the King's Lands (217), Stormpike's Order (1338), Find Bingles done.

[OC]|cffffffffThelsamar|r
At [TAR1105 Jern Hornhelm], [QT302] [QA273 Resupplying the Excavation] [G37.2,47.4 Loch Modan]
[OC]At [TAR1682 Yanni Stoutheart], [V] [G35.6,48.4 Loch Modan]
[O]At [TAR1139 Magistrate Bluntnose], [QA255 Mercenaries] - 4 Mo'grosh Ogres, 4 Brutes, 4 Enforcers (level 18-20 ELITE, northeast corner of the zone) - only if your friend is on; it is in the 20+ chapter otherwise [G34.6,44.5 Loch Modan]

[OC]Run east along the south shore to the wagon camp
At [TAR2057 Huldar], [QT273] [QA454 After the Ambush] [G52.2,69.3 Loch Modan]
At [TAR1379 Miran] next to him (respawns every 2 min if he is missing), [QT454] [QA309 Protecting the Shipment] [G52.2,69.4 Loch Modan]
[OC]Escort Miran east to the excavation. Two ambushes of 2-3 Dark Iron dwarves each; Miran dies fast, drop Stoneskin and take the hits yourself
At [TAR1344 Prospector Ironband], [QT309] [G65.9,65.6 Loch Modan]
[OC]|cffffcc00Gear:|r Foreman Belt (cloth) and Mud Stompers (mail) are both worse than what you have - take the belt to vendor
At [TAR1345 Magmar Fellhew], [QT436] [QA297 Gathering Idols] [G64.9,66.7 Loch Modan]
Kill [TAR1165 Stonesplinter Geomancer] and [TAR1167 Stonesplinter Digger] in the dig (level 17-19, geomancers cast Fire Blast - shock them) for 8 Carved Stone Idols [QC297] [G70,64 Loch Modan]
At [TAR1345 Magmar Fellhew], [QT297] [G64.9,66.7 Loch Modan]
[OC]|cffffcc00Gear:|r nothing for you (2H sword, 1H axe, wand) - take Thelsamar Axe (1H axe 9 dps +2 Agi) if you want a shield set, otherwise the wand to vendor
[OC]At [TAR1214 Aldren Cordon], [R][V] [G66.5,65 Loch Modan]

[OC]Run northeast to the boar fields north of Farstrider Lodge
[OC]Wait: A Hunter's Challenge has a 12 minute timer from when you accepted it; if it has expired, abandon it and re-take it from Daryl first
Kill 5 [TAR1192 Elder Mountain Boar] in the fields northwest of the lodge [QC258] [G66,40 Loch Modan]
[OC]Run southeast to Farstrider Lodge
Left of the entrance at [TAR1187 Daryl the Youngling], [QT258] [G83.5,65.5 Loch Modan]
[OC]|cffffcc00Gear:|r Daryl's Shortsword is a sword (shamans cannot use them) - take the Fine Cloth Shirt
Right of the entrance at [TAR1154 Marek Ironheart], [QT385] [QT86758] if you found Daggerfang [G81.8,61.7 Loch Modan]
[OC]|cffffcc00Gear:|r Rugged Cape (13 armor, no stats) only if you still wear Goat Fur Cloak. Daggerfang's Daggerfang (1.7 speed dagger +2 Agi) is a vendor item for you.
[O]If Daggerfang was not up before: he hunts the shore between the lodge and the excavation [QC86758] [G72,57 Loch Modan]
[O]Right of the entrance at [TAR1154 Marek Ironheart], [QT86758] [G81.8,61.7 Loch Modan]
Across from the entrance at [TAR1156 Vyrin Swiftwind], [QA271 Vyrin's Revenge] (Ol' Sooty, level 20 ELITE bear - group; the cave is west of Thelsamar) [G81.7,64.1 Loch Modan]
[OC]At [TAR954 Kat Sampson], [R][V] [G82.7,64.1 Loch Modan]

[OC]|cffffffffGroup quests - do these now if your friend is on, otherwise they are in the 20+ chapter|r
[O]|cFFFF0000GROUP 2+|r Ol' Sooty's cave is west of Thelsamar, above Stonesplinter Valley; kill [TAR1225 Ol' Sooty] (respawn 20 min) [QC271] [G37.9,63.4 Loch Modan]
[O]Back at the lodge at [TAR1187 Daryl the Youngling], [QT271] [QA531 Vyrin's Revenge] [G83.5,65.5 Loch Modan]
[O]At [TAR1156 Vyrin Swiftwind], [QT531] - take the |cff66ff66Hunting Satchel|r (10 slot bag) [G81.7,64.1 Loch Modan]
[O]|cFFFF0000GROUP 2+|r Grawmug's cave: the western of the two caves at the south end of Stonesplinter Valley, take the right-hand path deep in. Kill [TAR1205 Grawmug], [TAR1206 Gnasher] (heals) and [TAR1207 Brawler] [QC217] [G34.8,90.5 Loch Modan]
[O]At the bunker at [TAR1092 Captain Rugelfuss], [QT217] [G23.2,73.7 Loch Modan]
[OC]|cffffcc00Gear:|r Frontier Britches (+3 Str +3 Agi) lose to Deepgrave Trousers; take Dwarven Defender (shield +3 Sta) for the shield set or vendor
[O]|cFFFF0000GROUP 2+|r Mo'grosh ogre mound in the northeast: 4 [TAR1178 Mo'grosh Ogre], 4 [TAR1180 Mo'grosh Brute], 4 [TAR1179 Mo'grosh Enforcer] [QC255] [G71,24 Loch Modan]
[O]At [TAR1139 Magistrate Bluntnose], [QT255] [G34.6,44.5 Loch Modan]

[OC]|cffffffffLevel 17|r
|cFFfff8a3Hearth to [H Thelsamar]|r
[OC]|cffffcc00Bank/AH stop:|r you go through Ironforge anyway - bank the recipes, check the AH for 10 Coarse Dynamite (Alba Fairmoon's Westfall chain needs them, ~2,900 XP) and a leather chest with Str/Agi if you still wear the Robe of the Keeper
At [TAR1572 Thorgrum Borrelson], |cFFfff8a3Fly to [F Ironforge]|r [G33.9,51 Loch Modan]
[A Shaman] In the Forlorn Cavern at [TAR258098 Eldrun Stormbreaker], [T] train your level 14 and 16 spells - this is the LAST shaman trainer until you come back at 20 (none in Stormwind, Westfall or Redridge) [G46.2,13.2 Ironforge]
[OC]|cffffcc00Professions:|r Nissa Firestone (First Aid, 55.1,58.3) and Daryl Riknussun (Cooking, 60.1,36.4) teach Journeyman once the skill is 50; Balthus Stoneflayer (39.9,32.5) completes Camping 101: Skinning at Skinning 20
[OC]Run to Tinker Town and take the Deeprun Tram to Stormwind [G76,51 Ironforge]
[OC]|cffffffffFinished: Loch Modan second pass|r  -  continue with 17-18 Westfall
[NX 17-18 Westfall]
]], "Forever Dwarf Shaman 1-20")
