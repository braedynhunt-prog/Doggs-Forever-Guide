Guidelime.registerGuide([[
[N 26-27 Redridge and Eastvale]
[D Forever Warrior 1-30 (Braedyn)\\Lakeshire's wanted posters and Blackrock Bounty, Bellygrub and the optional Rethban mine in the west and north, one long east loop (Stonewatch Keep, the Blackrock camp in the south-east corner, the Tower of Ilgalar, Fangore), then the walk home through Eastvale and the Tower of Azora and a hearth to Sentinel Hill.]
[GA Alliance]
[OC]|cffffffffRedridge and Eastvale 26-27|r  -  you start in Stormwind at level ~26 with the Stockade hand-ins done; hearth = Sentinel Hill and it stays there. About 19,100 quest XP from 10 turn-ins on the core route (+2,900 for the optional ore and pendant quests), almost all of it in two loops out of Lakeshire. |cFFFF0000GROUP 2+|r parts: Gar'im and Morganth, and |cFFFF0000GROUP 3+|r for Gath'Ilzogg - 7,950 XP between the three. No HP numbers: the DB has none for any of the elites here.
[OC]|cffffcc00Carry in:|r What Comes Around... (386, needs the Head of Targorr from the Stockade), Messenger to Westfall (144), Morganth (249) and The Legend of Stalvan (74, the Sealed Crate from chapter 15). |cffffcc00Carry out:|r Messenger to Darkshire (145) and The Legend of Stalvan (78) go to Darkshire in chapter 17, Return to Kristoff (346, optional) to Stormwind in chapter 18, Songblade Search (95772) to the Excavation Site in chapter 22 - a long carry.
[OC]Your level-26 spells were trained in chapter 15 and the next trainer stop is chapter 18. Stock food, water and bandages for the two long loops, repair, and empty your bags

|cFFfff8a3Fly to [F Lakeshire]|r at [TAR352 Dungar Longdrink] on the gate ramp [G71.0,72.5 Stormwind City]

[OC]|cffffffffLakeshire|r  -  everything is within a minute of the town hall; the loops below start and end here
At [TAR903 Guard Howe] beside the flight master, [QA128 Blackrock Bounty] (15 Blackrock Champions at the north camp, 2,000 XP - |cff66ff66normal|r: level 24-25, not elite) [G26.4,57.9 Redridge Mountains]
[O]At [TAR341 Foreman Oslow], [QT345] [QA347 Rethban Ore] (only if you took Ink Supplies from Brother Paxton in chapter 15: 5 Rethban Ore from the north-west mine, 970 XP, handed in to Paxton in Northshire at the end of this chapter) [G27.1,48.6 Redridge Mountains]
At [TAR956 Dorin Songblade], [QA95772 Songblade Search] (requires level 24; his brother Daewyn is in the Excavation Site, chapter 22. Wowhead lists this quest for Dwarf, Night Elf and Gnome only while the DB allows a Skyborne: if Dorin does not offer it, skip it - unverified) [G25.8,46.4 Redridge Mountains]
On the notice board beside the town hall, [QA95999 WANTED: Incinerator Gar'im] (|cFFFF0000GROUP 2+|r, a level 23 elite at the Blackrock camp in the south-east corner, 2,550 XP; Wowhead lists his poster for Dwarf, Night Elf and Gnome only) [G24.4,46.2 Redridge Mountains]
[O]On the same board, [QA169 Wanted: Gath'Ilzogg] (|cFFFF0000GROUP 3+|r, a level 26 elite in the middle of Stonewatch Keep with three more elites beside him - read the keep note in loop 2 before you decide; 2,650 XP) [G24.5,46.2 Redridge Mountains]
At [TAR344 Magistrate Solomon], [QT144] [QA145 Messenger to Darkshire] (1,000 XP: Lord Ello Ebonlocke in Darkshire, chapter 17) [G24.9,44.5 Redridge Mountains]
At [TAR859 Guard Berton] at the bridge, [QT386] (2,000 XP) [G21.2,46.6 Redridge Mountains]
[OC][A Warrior] |cffffcc00Gear:|r take |cff66ff66Lucine Longsword|r (1H sword 14.0 dps +3 Sta)
On the poster by the bridge, [QA180 Wanted: Lieutenant Fangore] (a level 26 gnoll lieutenant in the north-east, not elite, 2,650 XP) [G21.7,46.4 Redridge Mountains]
At [TAR342 Martie Jainrose] at the west end of town, [QA34 An Unwelcome Guest] (Bellygrub, a level 24 boar - |cff66ff66normal|r: the DB and Wowhead Forever both list him as a normal mob, 1,950 XP) [G16.8,46.3 Redridge Mountains]
[OC]|cffffcc00Order:|r west (Bellygrub), north (the Rethban mine and the Champions), back to town, the long east loop, the hand-ins, then the walk home. |cff66ff66normal|r below means it finishes in one pass of that loop

[OC]|cffffffffLoop 1: Bellygrub, the Rethban mine and the Blackrock Champions|r  -  nothing here is elite
Kill [TAR345 Bellygrub] for his tusk - |cff66ff66normal|r (the DB has a single spawn at 10.6,49.3 in the west hills) [QC34] [G10.6,49.3 Redridge Mountains]
At [TAR342 Martie Jainrose], [QT34] (the reward is a Bouquet of Scarlet Begonias, an off-hand with no stats - vendor it) [G16.8,46.3 Redridge Mountains]
[OC]|cffffcc00Label - unknown drop rate, optional:|r Rethban Ore (347). The DB names the Redridge Drudgers (level 20-21, 14 spawns) and the tin and copper veins at the mine as sources and gives no rate. One pass of the Drudgers is fair; if five ores have not dropped, leave it - a miner can take the veins instead
[O]Gather 5 Rethban Ore from the [TAR580 Redridge Drudger] and the veins at the Rethban mine in the north-west corner [QC347] [G14.1,19.3 Redridge Mountains]
Kill 15 [TAR435 Blackrock Champion] at the north Blackrock camp - |cff66ff66normal|r (level 24-25, 24 spawns around 21-31,6-17, they stand in pairs; the camp's four elite Shadowcasters sit on its east edge at 30.5,8 - stay west of them) [QC128] [G24.8,11.5 Redridge Mountains]
Bandage to 115: Wool Bandages (orange all the way to 115) from the Stockade and Blackrock cloth until First Aid 115, where Heavy Wool opens at Menethil in chapter 18 (Silk is a 150 recipe, next bracket) [G24.8,11.5 Redridge Mountains]
[OC]Back down the north road to Lakeshire (~3 minutes). Howe's hand-in waits for the walk out, he is on the road to Three Corners

[OC]|cffffffffLoop 2: Stonewatch Keep, Gar'im, the Tower of Ilgalar and Fangore|r  -  one arc: east along the north shore, south through the keep to the south-east corner, north up the east side, then home along the road. Everything that is not named below (Blackrock Outrunners, Grunts and Renegades 19-22, Shadowhide gnolls 22-26) is a normal pull you can walk around
[OC]|cFFFF0000Stonewatch Keep|r (x 60-66, y 52-60): the DB puts Gath'Ilzogg (26 elite) at 64.5,55.8 with Singe (24 elite) 0.4 units from him, Blackrock Gladiators (24-25 elite) at 64.3,56.3 and 64.9,57.1, and Hunters, Sentries and Shadowcasters (21-24, elite) 2 units north. That is four elites on one spot, so Gath'Ilzogg is |cFFFF0000GROUP 3+|r - tank it with a healer and a damage dealer, or skip quest 169 (its lines are optional) and move on
Take the road east along the north shore (Alther's Mill is on the way) to the watch tower beside Stonewatch Keep [G58.2,49.8 Redridge Mountains]
[O]|cFFFF0000GROUP 2+|r Shadow Magic (115) still open from chapter 10? Pull the keep's west-edge [TAR436 Blackrock Shadowcaster] (elite, 22-23) one at a time for 3 Midnight Orbs [QC115] [G60.4,54.8 Redridge Mountains]
[O]|cFFFF0000GROUP 3+|r Kill [TAR334 Gath'Ilzogg] (level 26 elite, Warlord of the Blackrock Clan) with Singe and the Gladiators dead or held, and take his head [QC169] [G64.5,55.8 Redridge Mountains]
[OC]|cffffcc00Side note, unverified:|r Alonso in Ashenvale (43,70) offers Dragonslayer's Shield (78133, 2,550 XP) and the DB has no objective text for it. Season of Discovery sources put the shield on an object behind Gath'Ilzogg at 69.8,55.8 in Classic map space, which is about 64.7,55.8 on Forever's map (Redridge x shifts by 5.09) - the same spot as Singe. Chapter 12 skipped Alonso, so you do not hold the quest; look for a shield object while you are here and decide then
[O]|cFFFF0000GROUP 2+|r Tharil'zun (19) still open from chapter 10? Pull [TAR486 Tharil'zun] (level 24 elite) at the keep's south end, 3-4 units south of Gath'Ilzogg and Singe with a Gladiator about 2 units north of him - drag him south and away before you fight, then take his head [QC19] [G64.4,59.4 Redridge Mountains]
[OC]From the keep's south end head south-east through the Blackrock camps (Grunts and Outrunners, 19-21) to the corner of the zone
|cFFFF0000GROUP 2+|r Kill [TAR214519 Incinerator Gar'im] and take the Broken Staff - he is a level 23 elite on Wowhead Forever (the DB holds no rank for him) and wanders the camp: the DB has 122 positions for him between 67-73,79-87, so look around the middle of that patch and clear the Grunts and Outrunners (19-21) as they come [QC95999] [G71.5,84.3 Redridge Mountains]
Work back north up the east edge, past the foot of Stonewatch Falls, to the Tower of Ilgalar [G76.1,59.6 Redridge Mountains]
[OC]|cFFFF0000Morganth|r (elite, level 26 in the DB, level 27 on Wowhead Forever): the DB puts a dozen Shadowhide Darkweavers (25-26) and eleven Servants of Ilgalar (24-25) within five units of him in the tower. Pull the outer ones first, never more than two or three at once; the Darkweavers also drop the Glowing Shadowhide Pendant for Theocritus' Retrieval (1,400 XP, see Tower of Azora below)
|cFFFF0000GROUP 2+|r Kill [TAR397 Morganth] in the Tower of Ilgalar and take the Pendant of Shadow [QC249] [G75.0,49.5 Redridge Mountains]
Kill [TAR703 Lieutenant Fangore] for his paw - |cff66ff66normal|r (level 26, not elite, with Shadowhide Warriors 24-25 and Brutes around him) [QC180] [G75.1,37.1 Redridge Mountains]
[OC]|cffffcc00Item start, luck:|r a Glowing Shadowhide Pendant drops from Fangore and from every Shadowhide gnoll type here (Gnoll, Rabid Gnoll, Brute, Assassin, Warrior, Slayer, Darkweaver). The DB gives no drop rate: right-click it when it drops and keep it for Theocritus, never farm for it
[OC]Run back west along the north road to Lakeshire (~4 minutes)

[OC]|cffffffffLakeshire hand-ins|r
[O]At [TAR382 Marshal Marris], [QT115] [QT19] (only if you still held Shadow Magic or Tharil'zun from chapter 10 - gear picks as in chapter 10) [G28.4,49.0 Redridge Mountains]
[OC][A Warrior] |cffffcc00Gear (19):|r take |cff66ff66Fire Hardened Buckler|r (shield 528 armor 10 block)
[O]At [TAR341 Foreman Oslow], [QT98386] (Alther's Mill, only if it is still in your log from chapter 10) [G27.1,48.6 Redridge Mountains]
[O]In the town hall at [TAR900 Bailiff Conacher], [QT91] (Solomon's Law, only if it is still in your log from chapter 10) [G24.6,44.3 Redridge Mountains]
At [TAR344 Magistrate Solomon], [QT95999] [QT180] [G24.9,44.5 Redridge Mountains]
[OC][A Warrior] |cffffcc00Gear (95999):|r take |cff66ff66Alacritous Treads|r (mail feet +5 Str +5 Agi)
[O]At [TAR344 Magistrate Solomon], [QT169] (the DB lists no item reward for Gath'Ilzogg, Fangore or Blackrock Bounty) [G24.9,44.5 Redridge Mountains]
At [TAR903 Guard Howe] on the road to Three Corners, [QT128] [G26.4,57.9 Redridge Mountains]

[OC]|cffffffffWest into Elwynn|r  -  the road from Three Corners reaches the Eastvale Logging Camp first and the Tower of Azora second; Northshire is the optional last leg
Follow the road south-west to Three Corners and on into Elwynn (~2 minutes to the border) [G10.2,72.0 Redridge Mountains]
[OC]|cffffcc00Merchant camp|r is right here (10,72): sell, hand in any Waylaid Supplies to [TAR256389 Tamelyn Aldridge] (10.4,71.4) and glance at Auctioneer Quickcoin (9.4,71.8) for a cheap mail or shield upgrade
At [TAR294 Marshal Haggard] in the Eastvale Logging Camp, [QT74] [QA75 The Legend of Stalvan] [G84.6,69.4 Elwynn Forest]
[O][A Warrior] Also at [TAR294 Marshal Haggard], [QT1666] [QA1667 Dead-tooth Jack] (840 XP: his badge is in Dead-tooth's Strongbox south-east of the camp) [G84.6,69.4 Elwynn Forest]
Upstairs in his house, open Marshal Haggard's Chest for the Faded Journal Page [QC75] [G85.7,69.5 Elwynn Forest]
Back with [TAR294 Marshal Haggard], [QT75] [QA78 The Legend of Stalvan] (570 XP: Tavernkeep Smitts in Darkshire, chapter 17) [G84.6,69.4 Elwynn Forest]
[O][A Warrior] South-east of the camp, kill [TAR6093 Dead-Tooth Jack] (level 11) for Dead-tooth's Key and open Dead-tooth's Strongbox beside him for Marshal Haggard's Badge [QC1667] [G89.4,79.0 Elwynn Forest]
[O][A Warrior] Back at [TAR294 Marshal Haggard], [QT1667] (840 XP) [G84.6,69.4 Elwynn Forest]
[OC][A Warrior] |cffffcc00Gear (1667):|r Haggard's Axe / Hammer / Sword / Dagger are level-10 weapons (7.6-7.8 dps +1 Sta) - XP only at 27, take any and vendor it
At the Tower of Azora, [TAR313 Theocritus] takes the Pendant of Shadow [QT249] (2,750 XP) [G65.2,69.7 Elwynn Forest]
[OC][A Warrior] |cffffcc00Gear:|r take |cff66ff66Shadow Gauntlets|r (mail hands +5 Str +4 Sta)
[O]At [TAR313 Theocritus], if a Glowing Shadowhide Pendant dropped, right-click it [QA178 Theocritus' Retrieval] and hand it in [QT178] (1,400 XP, and Restoring Balm: a 180 HP heal over 12 seconds, 2 minute cooldown) [G65.2,69.7 Elwynn Forest]
[O]Northshire Abbey is a 4-minute walk north-west: at [TAR951 Brother Paxton] in the library, [QT347] [QA346 Return to Kristoff] (970 XP now; Kristoff in Cathedral Square, chapter 18, pays 1,950 XP and Wandering Boots, cloth +4 Sta +4 Int). If you skip the detour, abandon Rethban Ore (347) [G49.6,40.4 Elwynn Forest]
|cFFfff8a3Hearth to [H Sentinel Hill]|r
At [TAR523 Thor], |cFFfff8a3Fly to [F Darkshire]|r [G56.5,52.6 Westfall]
[OC]|cffffcc00Check:|r new in the log: Messenger to Darkshire (145), The Legend of Stalvan (78), Songblade Search (95772) and, if you took the detour, Return to Kristoff (346). Next: Darkshire
[NX 27-28 Duskwood: Sven and the Hermit]
]], "Forever Warrior 1-30")
