Guidelime.registerGuide([[
[N 20-21 Ruins of Lordaeron]
[D Forever Alliance 1-30 (Braedyn)\\Level-20 errands in Stormwind, the boats north to Southshore, the trek to the Ruins of Lordaeron (Forever's new 16-22 dungeon above the Undercity, 4 Alliance quests all picked up inside) and the hand-ins back home.]
[GA Alliance]
[OC]|cffffffffLevel 20|r  -  you are in Cathedral Square with the Deadmines done; hearth = Sentinel Hill. This chapter is a dungeon trip: ~10,900 quest XP plus a full clear of 18-22 mobs, and the best 20-22 gear on the route. Do it now - the mobs go grey at 26.
[OC]|cffffcc00Why RoL first:|r the four Alliance quests are picked up INSIDE the instance (nothing to fetch beforehand) and hand in back in Stormwind. The dungeon sits in Tirisfal Glades, so the trip is boats + a run through Horde country; the hearth brings you straight back.
[O][A Hunter] Train your level-20 spells now if you did not after the Deadmines: [TAR5515 Einris Brightspear] in the Dwarven District (Aspect of the Cheetah, Aimed Shot, Freezing Trap) [G67.3,36.2 Stormwind City]
[O][A Hunter] [TAR5510 Thulman Flintcrag] by the Dwarven District smithy sells Heavy Shot - buy 600 [G62.0,36.6 Stormwind City]
[O]Journeyman Skinning/Mining if you did not get it at 17 (needs skill 50; most people are past 50 by now): [TAR5513 Gelman Stonehand] teaches Mining here in the Dwarven District (Human: he also takes Camping 101: Mining at Mining 20) and [TAR1292 Maris Granger] teaches Skinning in Old Town (72.1,62.2); shaman, you can do both in Ironforge on your tram stop instead - Balthus Stoneflayer (39.9,32.5) and Geofram Bouldertoe (50.0,26.3) [G59.2,37.8 Stormwind City]
[O][A Hunter] Weapon skills while you are here: [TAR11867 Woo Ping] in the Trade District teaches Staves and Polearms (10 silver each) - the Ruins drop a +9 Agility staff [G61.9,70.7 Stormwind City]
At [TAR1719 Warden Thelwater] outside the Stockade, [QT389] - he offers The Stockade Riots now; leave it, the Stockade is chapter 15 [G51.5,69.4 Stormwind City]
In the Park at [TAR4984 Argos Nightwhisper], [QA3765 The Corruption Abroad] (1,450 XP for talking to his brother in Auberdine, which the boat passes - it also opens the Blackfathom quest) [G36.2,67.6 Stormwind City]
[OC][A Shaman] |cffffffffCall of Water (Water Totem)|r is a 9-part chain that bounces between Ironforge, Loch Modan, the Wetlands, Redridge, Ashenvale and Westfall: ~10,500 XP. It is threaded through the next chapters; part 1 starts at your trainer, so take the tram now
[A Shaman] Deeprun Tram in the Dwarven District to Ironforge [G73.8,49.2 Stormwind City]
[A Shaman] In the Forlorn Cavern at [TAR258098 Eldrun Stormbreaker], [T] train your level 20 spells (Ghost Wolf, Frost Shock, Healing Stream Totem, Lesser Healing Wave, Totemic Recall) and [QA94494 Call of Water] (goes to Norric Lochthane, north Loch Modan, chapter 09) [G46.2,13.2 Ironforge]
[A Shaman] Two steps away at [TAR2786 Gerrig Bonegrip], [QA971 Knowledge in the Deeps] (2,750 XP - the Lorgalis Manuscript sits in a chest in Blackfathom Deeps, chapter 13) [G50.8,5.6 Ironforge]
[A Shaman] Tram back to Stormwind [G76.5,51.5 Ironforge]
[O][A Hunter] Knowledge in the Deeps (971, 2,750 XP, a chest in Blackfathom) starts at Gerrig Bonegrip in Ironforge's Forlorn Cavern (50.8,5.6). If you ever take the tram before chapter 13, grab it; otherwise skip - it is not worth a round trip on its own [G73.8,49.2 Stormwind City]
[OC]Stock 20 food and 20 water (vendors in the Trade District), repair, empty your bags - the Ruins drop a lot of green loot
[OC]|cffffffffThe way north|r  -  Stormwind Harbor boat to Auberdine (~5 min), then the Auberdine boat to Menethil Harbor, and in Forever that same boat carries on to |cff66ff66Southshore|r in Hillsbrad. Stay aboard at Menethil.
Walk down to the harbor; the Auberdine boat leaves from the northern pier (the sign on the dock names the destination) [G24.5,4 Stormwind City]
Ride the boat to Auberdine. On the Auberdine dock at [TAR8997 Gershala Nightwhisper], [QT3765] [QA1275 Researching the Corruption] (8 Corrupted Brain Stems from the Fallenroot satyrs in and around Blackfathom - chapter 13) [G38.3,43 Darkshore]
[O]At [TAR2913 Archaeologist Hollee] on the same dock, [QA98461 Unrequited Love] (165 XP breadcrumb to Menethil - hand in whenever you are there) [G37.4,41.8 Darkshore]
Cross the dock and take the Menethil boat; stay on it through Menethil until it docks at Southshore [G33.5,40 Darkshore]
At Southshore get the [P] flight path (you will fly back here for the Hillsbrad quests at 29-30) [G49.4,52.4 Hillsbrad Foothills]
[OC]|cFFFF0000The trek (15-20 min at 20):|r north out of Southshore, keep WEST of the road - Tarren Mill (Horde town, 55+ guards) is in the north-east; cross the Hillsbrad Fields (level 20-24 farmers and Syndicate), then the pass in the north-west corner into Alterac and down into the Dalaran crater (22-24 Kirin Tor mages, avoidable). Dalaran sits on the west shore of Lordamere Lake.
Run to the Hillsbrad Fields [G33,42 Hillsbrad Foothills]
Through the north-west pass to Dalaran [G18,72 Alterac Mountains]
[OC]Swim from the Dalaran shore north across Lordamere Lake until the zone text says Tirisfal Glades. The ruined city on the shore ahead is the Ruins of Lordaeron; the instance portal is in the courtyard past the broken gates (Undercity's Deathguards patrol the courtyard - a death here is cheap: the spirit healer stands right outside the portal, so release and ghost in)
Swim to the Ruins of Lordaeron courtyard and enter the instance [G61,67 Tirisfal Glades]
[OC][A Shaman] Ghost Wolf for the whole trek (outdoors only) - it is why you trained first
[OC][A Hunter] Aspect of the Cheetah for the trek; swap to Hawk before the first pull

[OC]|cffffffffRuins of Lordaeron|r  -  group of 5, finder level 15, bosses 18-22, ~45 min. All four quests come from inside:
[OC]|cffffcc00?|r Abominable Creatures (95250) - the Baron's head - |cff66ff66normal|r, from Captain Truman at the entrance
[OC]|cffffcc00?|r Bloodied Insignia (95195) - 10 insignias from the undead - |cff66ff66normal|r, the first one you loot starts the quest; the skeletons/cadavers/ghouls drop them all run long, everyone loots their own
[OC]|cffffcc00?|r Crest of Lordaeron (95189) - |cff66ff66normal|r, a clickable crest lying on the ground (several possible spots along the route - look for the glinting shield); click it to start, hand in to Lady Dena Kennedy in Stormwind
[OC]|cffffcc00?|r Remember That I Love You (92415) - |cff66ff66normal|r, a Blood-Stained Parchment lying next to the last boss, Rath'mael; click it to start, hand in to the orphan matron in Stormwind
At [TAR265701 Captain Truman] just inside, [QA95250 Abominable Creatures]
[O]Loot a Bloodied Insignia from the first undead you kill and right-click it [QA95195 Bloodied Insignia], then keep looting [QC95195]
[O]Click the Crest of Lordaeron when you see it lying along the route [QA95189 Crest of Lordaeron]
[OC]|cffffffffThe run|r  -  spider wing first: Venom Lurkers / Spiders / Tarantulas in patrolling packs - pull them back to you, do not fight next to a second pack. |cffffcc00Witherfang|r (patrols King's Alley) comes with two spiders: kill those first; Leech Poison on the tank - shaman, Poison Cleansing Totem once you have the Water Totem, otherwise just heal through it.
[OC]|cffffcc00The Baron|r: Knockout = a big hit plus a threat drop; the tank stays at full health going in, everyone stops DPS for two seconds after each Knockout. Loot the Head [QC95250] - one kill only: Wowhead Forever lists the Head at ~15%, which is probably non-quest-holders skewing the count, but if it does not drop, do NOT re-run for it; abandon the quest on the way out
[OC]|cffffcc00Viktor the Vile|r (optional boss): light the chimney fire in the south-west building of Lordamere Overlook by the graveyard - 5 waves of adds, then Viktor (Leech Poison, hard melee). Let the tank pick each wave up first.
[OC]Flesh Golems patrol the Overlook: Knock Away throws the tank into other packs - pull them to open ground. Ghoul packs of 3-4 hit hard: one pack at a time.
[OC]|cffffcc00The Abandoned|r (Market Street statue event): 3 waves, then the boss - Frost Nova, Life Drain on the tank, a chill on anyone who melees him. Skeletal Soldier packs and Shrieking Banshees (silence) guard the street - stuns are your friend.
[OC]|cffffcc00Bjork|r: a short Anti-Magic Shield, otherwise tank and spank. |cffffcc00Rath'mael|r (last): Flamestrike lands where the tank stood when the cast began - everyone steps out of the fire; interrupt it (Earth Shock) when you can.
Click the Blood-Stained Parchment lying beside Rath'mael's platform [QA92415 Remember That I Love You]
[OC][A Shaman] |cffffcc00Loot calls (rolls):|r |cff66ff66Segmented Spider Leg|r (Witherfang - staff 17.5 dps +9 Agi +5 Spi: a straight upgrade over Smite's Hammer or Rockslicer) or |cff66ff66Corpse Chopper|r (2H axe 18.2 dps, no stats - about equal; take whichever drops). Bloodied Chestwraps (Viktor, leather +7 Agi +9 Spi, ~33%) - roll: on the weights a small upgrade over Blackened Defias Armor, 14.9 vs 10.6, all of it Spirit (a tie if Spirit proves weak). Witherbite Bracers (Witherfang, +4 Agi +5 spell damage, ~29%) edge Bravo's Armbands, 10.9 vs 8.6, only if spell damage holds up - roll if nobody needs them. Mirror of Rath'mael (shield +5 Str) for the shield set. Atrophic Girdle, Abomination Bones, Bonerust Leggings, Vilewalkers, Grip of Fear are MAIL - not until 40, pass. Meathook Slicer, Vileblood Scimitar, Haunting Blade: pass.
[OC][A Hunter] |cffffcc00Loot calls (rolls):|r |cff66ff66Segmented Spider Leg|r (Witherfang - staff +9 Agi +5 Spi) IF you trained Staves: your best stat stick over the Piercing Axe. Witherbite Bracers (+4 Agi +5 spell) lose to Bravo's Armbands - pass. Everything else is mail/cloth/caster/one-handers - pass. Keep your ammo count up: ~300 shots for the clear.
Hand in to [TAR265701 Captain Truman] at the entrance on the way out [QT95250] - take |cff66ff66Grave Shroud|r (cloak +3 Str +3 Sta) if your cloak has no stats; otherwise the Slain Baron's Signet (ring +3 Sta +1 Def) fills an empty ring slot. Monstrous Cleaver (2H sword 15.2 dps) is worse than what you carry
|cFFfff8a3Hearth to [H Sentinel Hill]|r then at [TAR523 Thor], |cFFfff8a3Fly to [F Stormwind]|r [G56.5,52.6 Westfall]
[OC]|cffffffffHand-ins in Stormwind|r
At the Stockade gate at [TAR466 General Marcus Jonathan], [QT95195] - |cff66ff66Duty Bound Leggings|r (leather legs +6 Agi +4 Int) are an upgrade for both of you unless your legs already carry 6+ Agility; Remembrance Armor is mail - pass [G69.2,82.7 Stormwind City]
In Cathedral Square at [TAR14450 Orphan Matron Nightingale], [QT92415] [QA95161 Remember That I Love You] (deliver the letter to Avette Fellwood in Darkshire - chapter 14; the Tarnished Locket is a 175-XP neck with -3 Str, vendor it) [G56.3,54 Stormwind City]
[O][TAR15991 Lady Dena Kennedy] walks the new quarter in the far north of the city, above the Cathedral - hand in the crest if you found one [QT95189] (2,600 XP + a Small Sack of Gems) [G62.6,5.8 Stormwind City]
[OC]|cffffcc00Check:|r log should hold Messenger to Stormwind (121), The Price of Shoes (118), Shadow Magic (115), Tharil'zun (19), Researching the Corruption (1275), Remember That I Love You (95161), Stormpike's Delivery (353) and, shaman, Call of Water (94494) + Knowledge in the Deeps (971). Next: fly to Loch Modan
[NX 21-22 Loch Modan and Menethil]
]], "Forever Alliance 1-30")
