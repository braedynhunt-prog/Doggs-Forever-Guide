Guidelime.registerGuide([[
[N 15-16 Hall of Thanes]
[D Forever Druid 1-30 (Braedyn)\\The new Ironforge dungeon (finder level 13, quests 15-16): pickups, the run with normal/grind labels per quest, loot to roll on, hand-ins.]
[GA Alliance]
[OC]|cffffffffIronforge - Hall of Thanes|r  -  5 quests, ~6,050 XP, and the Ironforge Greathammer
[OC]|cffffcc00Bring:|r your friend + 3 more (level 15-17 is comfortable) - find a tank and a healer; you are bear dps. Food, water and bandages for between pulls.

[OC]|cffffffffIronforge errands first|r
In the Hall of Explorers at [TAR1356 Prospector Stormpike], [QT301] [QA302 Powder to Ironband] [G74.6,11.7 Ironforge]
[OC]No druid trainer in Ironforge: Swipe (16) waits for Mathrengyl in Darnassus at the start of the Westfall chapter
[OC]In the Commons, [R][V] and stock 20+ water [G34,60 Ironforge]
At [TAR5159 Daryl Riknussun] (east side of the Great Forge), learn Journeyman Cooking NOW if you still have not - this is your last Ironforge stop before Marek's Crocolisk Steak recipe (Cooking 80) in the 16-17 chapter, and Apprentice stops at 75. Short of 50? Cook your boar meat, ribs and Longjaw at his fire until you are there [G60.1,36.4 Ironforge]
[O]In the Forlorn Cavern at [TAR5161 Grimnur Stonebrand], learn Journeyman Fishing if Fishing is 50 [G48.1,6.9 Ironforge]
[O]At [TAR5150 Nissa Firestone], learn Journeyman First Aid (and Heavy Linen) if you were short of 50 in chapter 2 [G55.1,58.3 Ironforge]


[OC]|cffffcc00Pre-dungeon quest log:|r
[OC]|cffffcc00?|r The Restless Dead (96394) - Afadra Dunwall, 32.4,47.8
[OC]|cffffcc00?|r Important Heirlooms (96403) - Thom Filch, 31.4,45.4
[OC]|cffffcc00?|r Old Ironforge Incursion (96393) - from Earthseer Farsen in Dun Morogh after the Underground Map
[OC]Starts inside: An Ancient Grudge (Ghostly Attendant), The Treaty of Understanding (tablet in the last room)
[OC]If you missed them: Afadra Dunwall (32.4,47.8) and Thom Filch (31.4,45.4) stand between the Commons and the Mystic Ward

[OC]|cffffffffThe run|r
[OC]|cffffcc00Camp before you zone in:|r at the portal, one of you drops a Basic Campfire (Cooking), then everyone adds one profession object (your Camp Chair, your friend's) and sits 1 minute - the buffs last an hour, about one run
[OC]Entrance: go into the High Seat (Magni's throne room), take the passage on the LEFT of the throne down into Old Ironforge; the Hall of Thanes portal is at the bottom [G39,55 Ironforge]
[OC]|cffffcc00Quest labels:|r Restless Dead = |cff66ff66normal|r (the ghosts are the trash of the first wing). Important Heirlooms = |cff66ff66normal|r (8 relics you click as you go; ask the group to leave them, and clear the wing if you are short). Ancient Grudge = |cff66ff66normal|r (boss 1). Old Ironforge Incursion = |cff66ff66normal|r (boss 4). Treaty = |cff66ff66normal|r (tablet behind a door in the last room).
[OC]|cffffffffWest wing|r
[OC]|cffffcc00Bear Form for the run:|r you are melee dps who can off-tank. Enrage before a pull for rage, Demoralizing Roar on each pack, Maul the kill target (Swipe once you have it at 16), Bash a Dark Iron Summoner's cast, pick up adds that run to the healer - and Growl the boss if the tank dies. Casters (Dark Iron Summoners) die first (Classic reasoning, unverified on Forever)
Just inside, talk to the [TAR265002 Ghostly Attendant], [QA96395 An Ancient Grudge]
[O]|cff66ff66Ongoing:|r kill 15 [TAR263389 Enraged Apparition] and 10 [TAR263390 Tormented Soul] in the first wing [QC96394]
[O]|cff66ff66Ongoing:|r click 8 Dwarven Heirlooms (relics on the floor and shelves through the whole dungeon) [QC96403]
[OC]|cffffffffBoss 1 - Faldrim Anvilmar|r (undead, Anvilmar's Rest, the big central room)
[OC]Tank and spank. Mind Blast on random targets; Anvilmar's Curse petrifies and cuts attack speed 20% - stay near the tank so it only lands on him, and keep threat steady
Kill [TAR261306 Faldrim Anvilmar] [QC96395]
[OC][A Druid] |cffffcc00Loot (Faldrim Anvilmar):|r roll on |cff66ff66Spiritwraith Drape|r (cloak +3 Agi +4 Spi, 33.76% drop); |cff66ff66Aetherwisp Bracers|r (cloth wrist, 32.85% drop); |cff66ff66Ephemeral Choker|r (neck +5 Spi, 32.85% drop)
Back at the [TAR265002 Ghostly Attendant], [QT96395]
[OC][A Druid] |cffffcc00Gear:|r take |cff66ff66Catacomb Cloak|r (cloak +2 Sta +7 AP)

[OC]|cffffffffBoss 2 - Magmatus|r (fire elemental with a Dark Iron Summoner add)
[OC]Trash on the way: Dark Iron Summoners (fireballs - kill first), Engineers (throw dynamite), Bloodhound Runts (their bite is a disease, +6% damage taken - heal or bandage through it), Dark Iron Looters (fast dagger hits)
[OC]Combust is a 360 degree AoE around the boss: tank faces him away, melee stand spread and step out when he winds up
[OC]|cffffcc00Bear:|r pick up the Dark Iron Summoner add with Growl and Bash its casts while the tank turns Magmatus away; burn it, then back on the boss
Kill [TAR261316 Magmatus]
[OC][A Druid] |cffffcc00Loot (Magmatus):|r roll on |cff66ff66Fang of Magmatus|r (dagger 7.9 dps +4 Int, 34.81% drop); |cff66ff66Flamefist Grips|r (leather hands +5 Agi +5 Spi, 29.01% drop)

[OC]|cffffffffBoss 3 - Plunder|r (stone golem)
[OC]Knock Away knockback AoE and a charge that stuns a random player. Fight him in the tunnel you came through so the knockbacks push you into a wall, not into the next pack. Do not pull adds into him.
Kill [TAR261311 Plunder]
[OC][A Druid] |cffffcc00Loot (Plunder):|r roll on |cff66ff66Golemheart Stave|r (staff 11.9 dps, 33.97% drop)

[OC]|cffffffffBoss 4 - Durgen Dirgehammer|r (the Dark Iron commander, 2 Lesser Stone Golems + Looters)
[OC]Kill the two golems first (they hit hard and move fast), then Durgen. He fears the group and Rends - nobody has a fear break at this level, so let the tank re-grab him after it and heal up afterwards.
[OC]|cffffcc00Bear:|r Growl one of the two golems and hold it (Demoralizing Roar, Maul) while the tank takes the other; after Durgen's fear run straight back in
Kill [TAR261319 Durgen Dirgehammer] and loot his head [QC96393]
[OC][A Druid] |cffffcc00Loot (Durgen Dirgehammer):|r roll on |cff66ff66Direhammer Leggings|r (leather legs +4 Agi +7 Sta, 23.23% drop); |cff66ff66Robes of the Disgraced Thane|r (cloth chest +4 Spi, 23.23% drop)
Behind one of the doors in the last room, click the stone tablet, [QA98423 The Treaty of Understanding]
Finish the heirlooms and ghosts before you leave [QC96403] [QC96394]

[OC]|cffffffffHand-ins|r
At [TAR265003 Thom Filch], [QT96403] [G31.4,45.4 Ironforge]
[OC][A Druid] |cffffcc00Gear:|r take |cff66ff66Tomb Robber's Gloves|r (cloth hands +1 Sta +2 Int)
At [TAR264943 Afadra Dunwall], [QT96394] [G32.4,47.8 Ironforge]
[OC][A Druid] |cffffcc00Gear:|r take |cff66ff66Dusty Belt|r (leather waist +2 Agi +2 Spi)
In the High Seat at [TAR2784 King Magni Bronzebeard], [QT96393] [QT98423] [G39.4,55.4 Ironforge]
[OC][A Druid] |cffffcc00Gear (96393):|r take |cff66ff66Ironforge Greathammer|r (2H mace 16.0 dps)
[OC]|cffffffffLevel 16|r
At [TAR1573 Gryth Thurden], |cFFfff8a3Fly to [F Thelsamar]|r for the Loch Modan leftovers [G55.5,47.7 Ironforge]
[OC]|cffffffffFinished: Hall of Thanes|r  -  continue with 16-17 Loch Modan
[NX 16-17 Loch Modan]
]], "Forever Druid 1-30")
