Guidelime.registerGuide([[
[N 30-31 Gnomeregan]
[D Forever Druid 1-30 (Braedyn)\\The Ironforge round (hand-ins and the Gnomeregan pickups), the trogg tunnels outside the door, the Gnomeregan run with boss notes and loot calls, and the hand-ins in Kharanos and Ironforge.]
[GA Alliance]
[OC]|cffffffffLevel 30|r  -  you land in Ironforge from Southshore; hearth = Sentinel Hill and it stays there. This chapter is one dungeon, Gnomeregan (a full clear of 25-34 mobs, about 2 hours), wrapped in an Ironforge errand round and a trogg pass outside the door: about 19,900 quest XP on the core route, ~25,500 with the Prism and the Sparklematic and up to ~43,700 with every optional chain (For Further Study has no XP in the DB), nearly all of it handed in here (Gyrodrillmatic's 2,450 waits for Shoni, chapter 25). Group content: find a tank and a healer plus two more damage dealers; you are Cat Form damage
[OC]|cffffcc00Log check:|r from earlier chapters you should hold Gyrodrillmatic Excavationators (2928), Word to Ironforge (98300), Klockmort's Essentials (2925), For Further Study (98313) and, if you got them, Prehistoric Prism (98824, only if the Titan Relic dropped at the Excavation Site), Sully Balloo's Letter (637) and Castpipe's Task (2931). The other Gnomeregan quests are picked up below
[OC]|cffffcc00Sources:|r Forever's Gnomeregan is reported to be Classic's dungeon with only loot and rewards changed (Warcraft Tavern). Levels, drops, quests and item stats come from the Forever DB, which has no coordinates inside the instance and no drop rates; routes, boss tactics and object spots are Classic-era guide knowledge (Icy Veins, Almar's, Warcraft Tavern, warcraft.wiki.gg), not verified on Forever. The map pin on optional in-dungeon lines just points at the door
[OC]|cffffcc00Supplies:|r the gnome station just inside the door has vendors and a mailbox (Almar's), but arrive stocked: food and water for two hours, repair, empty bags, 3 silver per Sparklematic run (9 for tiers 1, 2 and the ring) and 30 silver if you go for Talvash's ring

[OC]|cffffffffIronforge round|r  -  about 15 minutes on foot: the optional Balloo/King chain, the Explorers, then Tinkertown last for the pickups. There is no druid trainer in Ironforge: if you did not train level 30 (Travel Form, Shred rank 2) in Darnassus, it waits for the Stormwind Park in chapter 25
[O]At [TAR2695 Sara Balloo], [QT637] [QA683 Sara Balloo's Plea] (2,450 XP for the letter, then a 7,400-XP chain) [G63.5,67.3 Ironforge]
At [TAR2784 King Magni Bronzebeard], [QT98300] (2,700 XP: Howin's missive from the Wetlands) [G39.1,56.2 Ironforge]
[O]At [TAR2784 King Magni Bronzebeard], [QT683] [QA686 A King's Tribute] [G39.1,56.2 Ironforge]
[O]At [TAR2790 Grand Mason Marblesten] in the south-west, [QT686] [G39.0,88.0 Ironforge]
[OC]|cffffcc00Alterac Granite (689):|r the next step wants 5 pieces, and the DB places that rock only in Hillsbrad Foothills (six spots around 43-45, 25-33), nothing near Ironforge. Do the next two lines only if the five are already in your bags; otherwise stop here. Nothing breaks: Marblesten offers 689 whenever you return with the granite, and the tail is 5,000 XP plus the Ironforge Memorial Ring
[O]At [TAR2790 Grand Mason Marblesten], [QA689 A King's Tribute] [QC689] [QT689] [QA700 A King's Tribute] (only with 5 Alterac Granite) [G39.0,88.0 Ironforge]
[O]At [TAR2784 King Magni Bronzebeard], [QT700] (2,500 XP; Ironforge Memorial Ring +5 Sta +4 Spi, only for an empty ring slot) [G39.1,56.2 Ironforge]
[O]At [TAR5387 High Explorer Magellas] in the Hall of Explorers, [QT98824] (3,150 XP; only if the Titan Relic dropped in chapter 22) [G69.9,18.6 Ironforge]
[OC][A Druid] |cffffcc00Gear:|r take |cff66ff66Heavehammer|r (2H mace 27.7 dps +32 AP)
At [TAR2916 Historian Karnik], [QT98313] (the DB lists no XP for this one) [G77.5,11.8 Ironforge]

[OC]|cffffffffTinkertown|r  -  the Gnomeregan pickups, a few steps apart
[O]At [TAR7944 Tinkmaster Overspark], [QT2923] (only if you skipped the Ironforge hop in chapter 15) [G69.5,50.3 Ironforge]
At [TAR7944 Tinkmaster Overspark], [QA2922 Save Techbot's Brain!] (2,650 XP, |cff66ff66normal|r: Techbot is ONE elite in a room outside the instance door, you kill him on the way in) [G69.5,50.3 Ironforge]
At [TAR6169 Klockmort Spannerspan], [QT2925] [QA2924 Essential Artificials] (3,050 XP: 12 Essential Artificials from Artificial Extrapolators inside, |cffffcc00search|r - see the dungeon notes) [G67.9,46.1 Ironforge]
[O]At [TAR7950 Master Mechanic Castpipe], [QT2931] [G69.8,48.1 Ironforge]
At [TAR7950 Master Mechanic Castpipe], [QA2930 Data Rescue] (3,650 XP: a punch card through four machines; the DB gives it no prerequisite, so it is open even if you skipped Castpipe's Task) [G69.8,48.1 Ironforge]
At [TAR7937 High Tinker Mekkatorque], [QA2929 The Grand Betrayal] (2,750 XP: kill Mekgineer Thermaplugg, the last boss) [G68.8,49.0 Ironforge]
At [TAR6569 Gnoarn], [QA2927 The Day After] (220 XP, the breadcrumb to Kharanos) [G69.2,50.5 Ironforge]
[OC]Leave Ironforge by the main gate and take the road down to Kharanos (about 3 minutes; Kharanos has no flight path)

[OC]|cffffffffKharanos and the exterior tunnels|r  -  the Gnogaine phial must be filled OUTSIDE the door and handed in before you go in (that unlocks the quest you finish inside), so do the whole exterior pass on this first trip and walk back to Ozzie only once
At [TAR1268 Ozzie Togglevolt] in Kharanos, [QT2927] [QA2926 Gnogaine] (2,200 XP: fill the Empty Leaden Collection Phial he gives you from an irradiated trogg, |cff66ff66normal|r) [G45.9,49.4 Dun Morogh]
[OC]Walk west past Brewnall Village to the Gnomeregan crater (the DB puts the entrance at 24.3,39.8). Classic-era (Icy Veins): an elevator at the crater drops you into the exterior tunnels, a big room with a train depot; the instance door is at the end of a tunnel along its left wall. Everything in this block happens in those tunnels, before the door
|cFFFF0000GROUP 3+|r Kill an [TAR6213 Irradiated Invader] (level 24-26 elite, HP not in the DB) and use the Empty Leaden Collection Phial on its corpse [QC2926] [G20.8,35.6 Dun Morogh]
|cFFFF0000GROUP 3+|r In his own room north of the depot, kill [TAR6231 Techbot] (level 26 elite) and loot Techbot's Memory Core [QC2922] [G19.8,31.9 Dun Morogh]
[OC]|cffffcc00Loot as you go:|r the exterior troggs (Caverndeep Invader, Looter and Pillager, Irradiated Invader and Pillager) drop Grime-Encrusted Objects (one per Sparklematic run: keep them all) and the Invaders also Robo-mechanical Guts. The White Punch Card drops from Caverndeep Invaders, Looters and Pillagers, Irradiated Invaders and Addled Lepers; the DB has no rates
[OC]|cffffcc00White Punch Card (Data Rescue):|r |cffffcc00luck|r. If none has dropped by the time Techbot is down, give it a few more minutes of kills; if it still will not come, let Data Rescue's 3,650 XP go rather than camp (the card can drop on any later visit)
[O]Use the White Punch Card on a Matrix Punchograph 3005-A (four machines, two near 22,32.6 and two near 22,31) to get a Yellow Punch Card [G22.0,32.6 Dun Morogh]
At [TAR1268 Ozzie Togglevolt], [QT2926] [QA2962 The Only Cure is More Green Glow] (2,450 XP: he hands you a Heavy Leaden Collection Phial, see the notes inside) [G45.9,49.4 Dun Morogh]
|cFFFF0000GROUP 5|r Back at the crater, ride the elevator down and enter Gnomeregan at the end of the exterior tunnels [G24.3,39.8 Dun Morogh]

[OC]|cffffffffGnomeregan|r  -  |cFFFF0000GROUP 5|r, recommended level 29-38 (Warcraft Tavern), mobs 25-34 and bosses 30-34 in the DB, ~2 hours. Your quests, with the honest label:
[OC]|cffffcc00?|r The Grand Betrayal (2929) - kill Mekgineer Thermaplugg - |cff66ff66normal|r, he is the last boss
[OC]|cffffcc00?|r Essential Artificials (2924) - 12 Essential Artificials, one per Artificial Extrapolator (a box on a wall or machine that vanishes when used) - |cffffcc00search|r: the DB has no positions for them, they sit all over the instance, so check every side room on the clear and expect to backtrack if you finish short
[OC]|cffffcc00?|r Gyrodrillmatic Excavationators (2928) - 24 Robo-mechanical Guts - |cffffcc00grind warning|r: 16+ mob types drop them (troggs, leper gnomes, slimes, the mechanicals, several bosses) but no rate is in the DB and 24 is a lot; the exterior kills count, so kill everything. Hands in to Shoni in Stormwind, chapter 25
[OC]|cffffcc00?|r Data Rescue (2930) - Prismatic Punch Card - |cff66ff66normal|r once you hold the White card: each Matrix Punchograph upgrades your current card one colour (White, Yellow, Blue, Red, Prismatic): 3005-A outside (done), 3005-B in the Dormitory, 3005-C on Electrocutioner's platform, 3005-D on the lower floor of the Engineering Labs
[OC]|cffffcc00?|r The Only Cure is More Green Glow (2962) - High Potency Radioactive Fallout - |cff66ff66normal|r but timed: use the Heavy Leaden Collection Phial on a LIVING glowing Irradiated Slime, Corrosive Lurker or Irradiated Horror (level 27-29 elites, no positions in the DB). The fallout vanishes about two hours after you take it (Warcraft Tavern), so take it as late in the run as you can; Ozzie wants the phial back too, keep it
[OC]|cffffcc00Optional:|r A Fine Mess (2904) - escort Kernobee out of the Dormitory - hands in to Scooty in Booty Bay, which this guide never passes: skip it unless Stranglethorn is next on your list

[OC]|cffffffffThe run|r  -  Classic-era layout (Icy Veins, Warcraft Tavern): narrow corridors joining multi-level rooms with jump-down points; mobs on a lower level can be pulled from above and run round to you with friends, so the tank pulls to a corner. Icy Veins wants a mage's crowd control on the humanoids: mark a kill order and hit the tank's target in Cat Form, from behind. If the tank dies, shift to Bear Form and Growl. Elites throughout, one pack at a time
[OC]|cffffcc00Clean Zone and the Sparklematic 5200|r  -  the machines stand in the first area inside the door (warcraft.wiki.gg). Three machines, three tiers, one rule: at each tier the three machines offer three different quest ids for the SAME job, so you do ONE quest per tier. Tier 1 is The Sparklematic 5200! (2951, or 4601 / 4602 on the other machines; Wowhead lists no XP), tier 2 is 2952 / 4605 / 4606 (2,450 XP, you need only one of them), tier 3 is More Sparklematic Action (2953 / 4603 / 4604), repeatable for an Object and 3 silver with no XP listed: skip it. A run eats one Grime-Encrusted Object plus 3 silver and returns a Sparklematic-Wrapped Box (a random gem, ore or stone). With two Objects from outside, do tiers 1 and 2 now; otherwise on the way out
[O]At a Sparklematic 5200 in the Clean Zone, [QA2951 The Sparklematic 5200!] [QT2951] (an Object and 3 silver; take whichever tier-1 quest your machine offers) [G24.3,39.8 Dun Morogh]
[O]At a Sparklematic 5200 in the Clean Zone, [QA2952 The Sparklematic 5200!] [QT2952] (2,450 XP; whichever tier-2 quest the machines offer) [G24.3,39.8 Dun Morogh]
[OC][A Druid] |cffffcc00Loot (Grubbis):|r roll on |cff66ff66Skullduggery Belt|r (leather waist +7 Spi +16 AP, 1.98% drop); |cff66ff66Stormrider's Leather Helm|r (leather head +13 Sta +10 Spi); |cff66ff66Wisdom's Leather Helm|r (leather head +13 Sta)
[OC][A Druid] |cffffcc00Loot (Viscous Fallout):|r roll on |cff66ff66Toxic Revenger|r (dagger 20.5 dps, 18.25% drop); |cff66ff66Hydrocane|r (staff 19.8 dps, 20.03% drop); |cff66ff66Acidic Walkers|r (cloth feet +8 Int +4 Spi, 59.01% drop)
[OC]|cffffcc00Grubbis|r (level 32 elite, optional): in the open room above the first jump-down, take the first offshoot to the left to Blastmaster Emi Shortfuse and hold off the trogg waves of his event; Grubbis then arrives with his basilisk Chomper (level 30 elite). Chomper first, both can be stunned or feared, otherwise tank and spank
[OC]|cffffcc00Viscous Fallout|r (level 30 elite elemental) in the big room below the jump-down (Hall of Gears): clear its trash first. Sources differ: one says tank and spank and immune to frost, another reports Toxic Volley (poison on everyone near him) and small oozes that split off, so spread out and kill the small ones fast; your Cure Poison clears the volley between oozes
[OC]|cffffcc00The Dormitory|r: from the upper level above Viscous Fallout take the south-west tunnel (do not drop off the side) to the Dormitory, where Matrix Punchograph 3005-B and Kernobee stand
[O]Use the Yellow Punch Card on Matrix Punchograph 3005-B in the Dormitory to get a Blue Punch Card
[OC]|cffffcc00Kernobee|r (optional): east of the 3005-B machine. Escort - everyone in the group must be on the quest before you talk to him; he does not fight or aggro (Warcraft Tavern) and if he dies he does not respawn. Take him to the Clockwerk Run exit; the hand-in is Scooty in Booty Bay, so only take it if Stranglethorn is next
[O]At [TAR7850 Kernobee] in the Dormitory, [QA2904 A Fine Mess] (2,450 XP at Scooty, Booty Bay) [G24.3,39.8 Dun Morogh]
[OC]|cffffcc00Electrocutioner 6000|r (level 32 elite mechanical) on the Launch Bay platform up the western tunnel: Chain Bolt chains to everyone standing together and Megavolt hits hard; sources disagree on interrupting them. The tank holds him at max melee range, facing away, everyone else spreads out (you stay behind him, apart from the other melee) and the healer tops up after each bolt. He drops the Workshop Key (back-door key, not needed)
[O]Use the Blue Punch Card on Matrix Punchograph 3005-C on his platform to get a Red Punch Card
[OC]|cffffcc00Crowd Pummeler 9-60|r (level 32 elite mechanical) in the Engineering Labs, down the narrow south tunnel off the main one (groups miss it by walking past): Arcing Smash, Trample and Crowd Pummel. Keep your back to a wall so you are not thrown off the edge, casters and healer stay at range, the tank holds him facing away and you stay behind him. Matrix Punchograph 3005-D stands on the lower floor of his room
Use the Red Punch Card on Matrix Punchograph 3005-D and take the Prismatic Punch Card [QC2930]
[OC][A Druid] |cffffcc00Loot (Electrocutioner 6000):|r roll on |cff66ff66Electrocutioner Lagnut|r (ring +4 Sta +7 Spi, 31.77% drop)
[OC][A Druid] |cffffcc00Loot (Crowd Pummeler 9-60):|r roll on |cff66ff66Manual Crowd Pummeler|r (2H mace 29.0 dps +16 Str +5 Agi, 33.03% drop); |cff66ff66Emblazoned Chestpiece|r (leather chest +7 Agi +6 Sta +6 Spi); |cff66ff66Thermaplugg Medal of Honor|r (neck +6 Sta +6 Spi +10 AP, 0.97% drop)
[OC][A Druid] |cffffcc00Loot (Dark Iron Ambassador):|r roll on |cff66ff66Royal Diplomatic Scepter|r (1H mace 15.2 dps +3 Sta +7 Spi, 21.62% drop)
[OC]|cffffcc00Dark Iron Ambassador|r (level 33 rare elite, optional) spawns in the tunnel between Electrocutioner and the final boss (Icy Veins). The tank pulls him away and picks up each Burning Servant he summons; kill the servants, interrupt his Fireball, healers stay at range (he also has Fire Shield and Fireball Volley). A Servant on the healer that the tank cannot reach: shift to Bear Form and Growl it
[OC]|cffffcc00Mekgineer Thermaplugg|r (level 34 elite mechanical, last boss) in the Tinkers' Court (Icy Veins: double back along the main tunnel, Almar's mentions a lift down; follow whatever your tank knows): he opens chutes round the room that send Walking Bombs at the group, and they explode on contact. The tank holds him mid-room, ranged kill each bomb before it arrives and one player runs to the red buttons at the foot of the chutes to close them - a cat (Dash from 26) is quick enough to be that player. Knock Away resets threat, so ease off until the tank has him back; more bombs at 50% and 20%
Kill Mekgineer Thermaplugg [QC2929]
[OC][A Druid] |cffffcc00Loot (Mekgineer Thermaplugg):|r roll on |cff66ff66Electromagnetic Gigaflux Reactivator|r (cloth head +8 Int +9 Spi, 9.92% drop)
[OC]|cffffcc00Trash loot:|r |cff66ff66Petrolspill Leggings|r (leather legs +14 Agi +6 Sta, +10% fire damage taken) are worth a roll until the Grand Betrayal legs. Caverndeep Trudgers are mail; Mechbuilder's Overalls and Hotshot Pilot's Gloves are cloth: pass
Keep clearing for what you are short of: Essential Artificials from the Extrapolators [QC2924]
Robo-mechanical Guts from the troggs, mechanicals and slimes [QC2928]
Take the High Potency Radioactive Fallout with the Heavy Leaden Collection Phial from a living glowing Irradiated mob if you have not [QC2962]
[OC]|cffffcc00Grime-Encrusted Ring|r (2945, requires level 28, optional): |cffffcc00luck|r - a Dark Iron Agent (level 32-33 elite, no positions in the DB) can drop it at an unknown rate, so never farm it. If it drops, right-click it to start the quest and clean it at a Sparklematic on the way out (3 silver; the DB ends the quest at one specific machine and Icy Veins says not every machine takes it, so try all three)
[O]At a Sparklematic 5200 in the Clean Zone, [QA2945 Grime-Encrusted Ring] [QT2945] [QA2947 Return of the Ring] (you get a Brilliant Gold Ring to take to Talvash in Ironforge) [G24.3,39.8 Dun Morogh]
[O]Not heading for Booty Bay? Drop A Fine Mess here if you took it [QS2904] [G24.3,39.8 Dun Morogh]
[OC]|cffffcc00Leaving:|r walk out the front door, the way back is cleared and the Sparklematics are on it. Do NOT hearth: it would drop you in Westfall, and Ozzie, Ironforge and the rewards are all east. The Workshop back door needs Electrocutioner's key and is not on your way

[OC]|cffffffffHand-ins|r  -  Kharanos first, then Ironforge
At [TAR1268 Ozzie Togglevolt], [QT2962] (2,450 XP; if the fallout vanished in the run, fetch another before you walk out of the instance) [G45.9,49.4 Dun Morogh]
At [TAR7944 Tinkmaster Overspark], [QT2922] (2,650 XP) [G69.5,50.3 Ironforge]
At [TAR6169 Klockmort Spannerspan], [QT2924] (3,050 XP) [G67.9,46.1 Ironforge]
At [TAR7950 Master Mechanic Castpipe], [QT2930] (3,650 XP) [G69.8,48.1 Ironforge]
[OC]|cffffcc00Gear (Data Rescue):|r the fixed Mechanic's Pipehammer is a 21.6-dps two-handed mace: wield it if your weapon is slower (it ties Mavoris's Warstaff from chapter 21 on dps), else vendor; the Repairman's Cape (+3 Int +5 Spi) only if your cloak has no stats
At [TAR7937 High Tinker Mekkatorque], [QT2929] (2,750 XP) [G68.8,49.0 Ironforge]
[OC][A Druid] |cffffcc00Gear:|r take |cff66ff66Triprunner Dungarees|r (leather legs +3 Str +18 Agi +6 Sta)
[O]At [TAR6826 Talvash del Kissel], [QT2947] [QA2948 Gnome Improvement] (2,700 + 2,750 XP: he wants the Brilliant Gold Ring, a Silver Bar, a Moss Agate and 30 silver - buy the bar and the agate at the Auction House, or mine them) [G36.4,3.6 Ironforge]
[O]At [TAR6826 Talvash del Kissel], [QT2948] (Talvash's Gold Ring: +10 Sta - wear it if a ring slot is empty or weaker) [G36.4,3.6 Ironforge]
[OC]|cffffcc00Check:|r log should now hold Gyrodrillmatic Excavationators (2928, completed, to Shoni in Stormwind - the first stop of chapter 25) and the carries from earlier chapters. Next: Ironforge to Stormwind by tram, then the loose ends
[NX 30-31 Loose Ends: Stormwind, Duskwood and Arathi]
]], "Forever Druid 1-30")
