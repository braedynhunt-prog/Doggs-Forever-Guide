Guidelime.registerGuide([[
[N 26-27 The Stockade]
[D Forever Druid 1-30 (Braedyn)\\Stormwind errands and the Gnomeregan pickups in Ironforge, the Stockade run (five elite bosses and a rare, with loot calls), the Defias chain up to Lady Katrana, and one trip to Elwynn for the apples, the Stalvan chain and Northshire.]
[GA Alliance]
[OC]|cffffffffLevel 26|r  -  you are in Darkshire with the Darkshire flight path learned; hearth = Sentinel Hill and it stays there. The chapter is one dungeon, the Stockade behind Warden Thelwater's gate in Stormwind (a full clear of 23-29 elites), wrapped in two rounds of Stormwind errands: about 19,200 quest XP on the core route, up to ~26,000 with every optional hand-in. Two Stockade bounties are completed here but paid later: Targorr's head (386) in Lakeshire (chapter 16) and Dextren Ward's hand (377) in Darkshire (chapter 17)
[OC]|cffffcc00Log check:|r What Comes Around... (386), Crime and Punishment (377), The Legend of Stalvan (69, from Clerk Daltry), A Friend of the Family (98190, from Menethil) and, only if you have them, Cleansing the Eye (293, Third Fleet), An Old History Book (337) and The Powers Below (968). Without 377 or 386 you only skip that boss's head; the loot is the same

At [TAR2409 Felicia Maline], |cFFfff8a3Fly to [F Stormwind]|r [G77.5,44.3 Duskwood]
[OC]|cffffffffStormwind round|r  -  you land on the gate ramp. The loop: Old Town, the Auction House, Cathedral Square, the Keep, the tram to Ironforge and back (optional), the Cathedral, the druid trainer in the Park, then the Stockade door. Nothing on it needs a fight
In Old Town at [TAR1721 Nikova Raskol], [QA388 The Color of Blood] (10 Red Wool Bandanas, dropped inside the Stockade: |cff66ff66normal|r, see the run notes) [G76.4,63.7 Stormwind City]
At the Auction House buy 3 [CI4306,3 Silk Cloth] for Tyrion's Items of Some Consequence later in this chapter (the DB lists no mob drops for silk, so buying is quicker than hunting it) [G61.1,70.7 Stormwind City]
[O]At [TAR1444 Brother Kristoff] in Cathedral Square, [QA343 Speaking of Fortitude] (195 XP: the first step of a 4-quest errand worth ~2,000 XP - Keep library, Northshire, Lakeshire, back to Northshire, ending here in chapter 18; skip the whole thing if you like) [G55.0,54.2 Stormwind City]
At [TAR7917 Brother Sarno], [QA2923 Tinkmaster Overspark] (210 XP, the door to the Gnomeregan quests: Overspark stands in Ironforge) [G51.0,48.4 Stormwind City]
[O]At [TAR1284 Archbishop Benedictus], [QT293] (only if you did the Third Fleet in chapter 09, 2,450 XP; the Eye of Paleth is a healer's off-hand, +13 healing: vendor it unless you will heal) [G50.3,45.5 Stormwind City]
At [TAR1748 Highlord Bolvar Fordragon] in the Keep, [QT98190] [QA98191 A Friend of the Family] [G80.2,38.4 Stormwind City]
[O]At [TAR1440 Milton Sheaf] in the Royal Library, [QT337] (only if An Old History Book dropped in Duskwood: 1,500 XP now; the Southshore follow-up 538 is taken on the chapter-18 Stormwind pass) [G77.1,30.2 Stormwind City]
[O]At [TAR1440 Milton Sheaf], [QT343] [QA344 Brother Paxton] [G77.1,30.2 Stormwind City]
[OC]Shoni the Shilent's Gyrodrillmatic Excavationators (2928, Gnomeregan) is taken on the chapter-18 Stormwind pass, closer to the run

[OC]|cffffffffIronforge hop|r  -  optional: only for Overspark's breadcrumb and The Powers Below if the book dropped (there is no druid trainer in Ironforge); chapter 24 takes Overspark anyway if you skip the hop
[O]Take the Deeprun Tram to Ironforge - optional: only Overspark (below) and The Powers Below if the book dropped; chapter 24 takes Overspark if you skip it [G73.8,49.2 Stormwind City]
[O]In Tinkertown at [TAR7944 Tinkmaster Overspark], [QT2923] (he then offers Save Techbot's Brain, 2922 - leave it, chapter 24 takes it on the way to the dungeon) [G69.5,50.3 Ironforge]
[OC]Gnoarn (The Day After, 2927) and High Tinker Mekkatorque (The Grand Betrayal, 2929) are chapter 24 pickups
[O]At [TAR2786 Gerrig Bonegrip], [QT968] (only if the Book: The Powers Below dropped in Darkshore, 1,700 XP) [G50.8,5.6 Ironforge]
[O]Tram back to Stormwind [G76.5,51.5 Ironforge]
At [TAR928 Lord Grayson Shadowbreaker] in the Cathedral, [QT98191] (his follow-up, The Shamed Lieutenant 98219, is taken on the chapter-18 Stormwind pass) [G48.4,50.2 Stormwind City]
[OC][A Druid] |cffffcc00Gear (98191):|r nothing to wield - the Knight's Lance is a polearm (no druid skill) and the Royal Dagger (8.5 dps, caster stats) is far below your two-hander: take the dagger and vendor it
In the Park at [TAR5504 Sheldras Moontree], [T] train level 26: Dash and Abolish Poison, plus Lacerate (25) and, if you skipped them in Darnassus, Rake, Tiger's Fury and Ferocious Bite (24) [G35.8,67.4 Stormwind City]
At [TAR1719 Warden Thelwater] at the Stockade gate, [QA391 The Stockade Riots] [QA387 Quell The Uprising] (the instance door is right beside him) [G51.5,69.4 Stormwind City]

[OC]|cffffffffThe Stockade|r  -  |cFFFF0000GROUP 5|r, dungeon range 24-32 (Icy Veins, Method), mobs 23-29 in the DB, ~25-30 min (Method says 15-25 for a geared group). Bosses, all elite: Targorr the Dread 24, Dextren Ward 26, Kam Deepfury 27, Hamhock 28, Bazil Thredd 29, plus the rare Bruegal Ironknuckle 26. Bring a tank and a healer; you are cat damage. Everything is picked up outside and nothing hands in inside; the door is in the city, so a food or repair run mid-dungeon is a one-minute walk
[OC]|cffffcc00Sources:|r the Forever DB gives the levels, drops, quests and item stats; the layout and boss tactics are from the Forever guides (Icy Veins, Method, Warcraft Tavern) and Classic-era knowledge, not verified on this server. Warcraft Tavern calls it unchanged from Classic except the loot
[OC]|cffffcc00Your quests:|r
[OC]|cffffcc00?|r The Stockade Riots (391) - the Head of Bazil Thredd - |cff66ff66normal|r, last boss of the right wing. Not shareable: everyone who wants it needs 389 done and 391 in the log
[OC]|cffffcc00?|r Quell the Uprising (387) - 10 Defias Prisoners, 8 Convicts and 8 Insurgents (elite 23-26) - |cff66ff66normal|r on a full clear, they are most of the trash; the DB has no spawn counts, so if you are short at the end, clear what you skipped. Shareable
[OC]|cffffcc00?|r The Color of Blood (388) - 10 Red Wool Bandanas - |cff66ff66normal|r: eight types drop them (Prisoner, Captive, Inmate, Convict, Insurgent, Dextren Ward, Bazil Thredd, Bruegal) but the DB has no drop rate, so expect to finish around Dextren or Bazil and keep killing if not. Shareable
[OC]|cffffcc00?|r What Comes Around... (386) - the Head of Targorr - |cff66ff66normal|r, first boss. Hands in to Guard Berton in Lakeshire (chapter 16)
[OC]|cffffcc00?|r Crime and Punishment (377) - the Hand of Dextren Ward - |cff66ff66normal|r, end of the left wing. Hands in to Councilman Millstipe in Darkshire (chapter 17)
[OC]|cffffcc00Not now:|r The Fury Runs Deep (378, Kam Deepfury's head, 2,750 XP) needs The Dark Iron War at Dun Modr first (chapter 19) and the head is a quest drop, so Kam gives you nothing for it today. Come back for him only if you want a second run

|cFFFF0000GROUP 5|r Gather at the door beside Warden Thelwater and enter The Stockade [G52.4,70.0 Stormwind City]
[OC]|cffffcc00Your job: cat damage|r (Classic reasoning, unverified on Forever): attack the tank's target from behind - Claw or Shred to five points, Rip on the bosses and Ferocious Bite on trash, Tiger's Fury before a burst. Captives and Inmates die first; Dash (26) catches a runner before it reaches the next cell. If the tank dies, Bear Form and Growl to keep the boss off the healer; Rebirth brings a fallen tank or healer back
[OC]|cffffcc00The cell block|r  -  T-shaped: the hallway straight ahead is Targorr's (he stands in one of several cells off it), the left wing ends at Dextren Ward with the rare Bruegal on the way, the right wing holds Kam, then Hamhock, then Bazil Thredd. The wings go in either order; this route is Targorr, left, right, so Bazil is last and the walk out is one corridor
[OC]|cffffcc00The trash|r  -  every pack is elite Defias, 23-26. Captives cast Infected Wound (more physical damage taken) and Inmates cast Rend, which hits harder on a wounded target: kill Captives and Inmates first. Convicts Backhand (a stun), Insurgents shout (Demoralizing Shout cuts your attack power). Pull small and keep the rooms apart: Targorr's adds can be pulled from the neighbouring cells in the first hallway
[OC]|cffffcc00Targorr the Dread|r (24 elite orc, first boss, in one of several cells with 1-3 Defias): he dual-wields, Thrash gives him extra swings and he enrages at low health (guides say 20-30%). Tank and spank: adds first, tank builds threat, healer on the tank
Kill [TAR1696 Targorr the Dread] and loot the Head of Targorr [QC386]
[OC][A Druid] |cffffcc00Loot (Targorr the Dread):|r roll on |cff66ff66Blackrock Harness|r (leather chest +8 Sta +14 AP, 1.70% drop); |cff66ff66Executioner Mantle|r (leather shoulders +9 Spi +10 AP, 1.50% drop); |cff66ff66Dark Horde Band|r (ring +6 Sta, 1.68% drop)
[OC]|cffffcc00Bruegal Ironknuckle|r (26 rare, left wing, not always there): no abilities of note, the adds round him are the danger. Tank and spank
[OC]|cffffcc00Dextren Ward|r (26 elite, end of the left wing): Intimidating Shout is an area fear. Clear every cell near his room first and pull him where a fear cannot carry anyone into another room (Method)
[OC]|cffffcc00Cat (Dextren):|r fight him only where the tank has pulled him, in a cleared cell or corridor, so a fear cannot carry you into a pack; after each fear wait for the tank's first hit before you open again
Kill [TAR1663 Dextren Ward] and loot the Hand of Dextren Ward [QC377]
[OC][A Druid] |cffffcc00Loot (Bruegal Ironknuckle):|r roll on |cff66ff66Prison Shank|r (dagger 17.8 dps +6 Agi +2 Sta, 19.82% drop); |cff66ff66Iron Knuckles|r (fist weapon 17.6 dps, 18.50% drop)
[OC]|cffffcc00Kam Deepfury|r (27 elite Dark Iron dwarf, a cell in the right wing): Shield Slam stuns his target for 2 seconds and hits hard, and Improved Blocking raises his block for 6 seconds. The healer watches the tank through each stun, DPS wait a few seconds for threat. Adds first
[OC]|cffffcc00Hamhock|r (28 elite ogre mage, at the end of the wing with 2 Defias): Chain Lightning is interruptible and he Bloodlusts himself and his adds (+30% speed, purgeable). Kill the two Defias, then interrupt him and purge the Bloodlust if anyone can, and stay spread so the chain jumps less
[OC]|cffffcc00Bazil Thredd|r (29 elite, last boss of the right wing and the end of this route): dual-wields and hits hard; Smoke Bomb stuns everyone near him for 4 seconds, so ranged players keep their distance and the healer tops the tank off first. Sources disagree on adds, so clear the room before you start
[OC]|cffffcc00Cat (Kam, Hamhock, Bazil):|r when Kam's Shield Slam stuns the tank, stop for a second so you do not pull him; on Hamhock kill his two Defias first and stay spread so Chain Lightning jumps less; on Bazil stay at his back, and Smoke Bomb stuns you too in melee, so give the healer room
Kill [TAR1716 Bazil Thredd] and loot the Head of Bazil Thredd [QC391]
[OC][A Druid] |cffffcc00Loot (Kam Deepfury):|r roll on |cff66ff66Kam's Walking Stick|r (staff 17.7 dps +10 Agi +3 Int, 2.93% drop); |cff66ff66Demolition Girdle|r (leather waist +8 Str, 2.19% drop)
[OC][A Druid] |cffffcc00Loot (Bazil Thredd):|r roll on |cff66ff66Defias Jailbreakers|r (leather hands +6 Agi +7 Sta, 0.98% drop); |cff66ff66Stormrider's Leather Helm|r (leather head +13 Sta +10 Spi); |cff66ff66Combat Cloak|r (cloak +6 Sta +2 Spi)
Check the tallies: kill whatever Defias you still need before you leave [QC387] [QC388]
[OC]|cffffcc00Trash loot:|r |cff66ff66Defias Renegade Ring|r (+4 Agi +6 Sta, req 21, unique) drops from the five Defias types: take it for an empty or weak ring slot, the Ring of Precision from Blackfathom is the same tier. Superior Boots (Targorr, Kam, Bruegal) are leather boots with a random enchantment: read the suffix before you roll

[OC]|cffffffffHand-ins and the Defias chain|r  -  you leave by the door in Stormwind. One loop through the city (Trade District, Cathedral Square, Old Town, Keep) with one trip to Elwynn in the middle
At [TAR1719 Warden Thelwater], [QT391] [QT387] [QA392 The Curious Visitor] (391 and 387 pay 25 and 40 silver) [G51.5,69.4 Stormwind City]
In Cathedral Square at [TAR1646 Baros Alexston], [QT392] [QA393 Shadow of the Past] [QT97914 Expanding Horizons] [QA97926 Making Do] (Making Do is Alexston's reply for Thundris in Auberdine: handed in on the Darnassus trip) [G57.7,47.9 Stormwind City]
In Old Town at [TAR332 Master Mathias Shaw], [QT393] [QA350 Look to an Old Friend] [G78.3,70.7 Stormwind City]
Round the corner at [TAR1721 Nikova Raskol], [QT388] (2,650 XP and 40 silver) [G76.4,63.7 Stormwind City]
In the Trade District at [TAR482 Elling Trias], [QT350] [QA2745 Infiltrating the Castle] [G66.0,74.1 Stormwind City]
At [TAR1303 Felicia Gump] (herbalism supplies, by the Trade District canal gate), [V] buy 1 Stormwind Seasoning Herbs for Seasoned Wolf Kabobs [G69.3,71.3 Stormwind City]
In the Keep at [TAR7766 Tyrion], [QT2745] [QA2746 Items of Some Consequence] (3 Silk Cloth, already in your bags from the Auction House, and 2 of Clara's Fresh Apples from Elwynn) [G73.2,35.6 Stormwind City]

[OC]|cffffffffElwynn trip|r  -  one out-and-back, about 10 minutes (14 with Paxton), for the apples, the Stalvan chain and (optionally) Brother Paxton. The Stalvan stop is bundled here instead of before the run so that Elwynn costs one trip, not two. Leave by the main gate and take the road south to Goldshire
Take 2 of Clara's Fresh Apples from the basket north-west of Goldshire (a quest-only object, so it shows because 2746 is in your log; the DB has one spawn, so if a click gives one apple, wait for the respawn) [QC2746] [G34.0,57.2 Elwynn Forest]
At the Lion's Pride Inn in Goldshire, [TAR295 Innkeeper Farley], [QT69] [QA70 The Legend of Stalvan] (570 XP now, 1,700 more in the city) [G43.8,65.8 Elwynn Forest]
Open the Storage Chest at the inn and take Stalvan's Undelivered Letter [QC70] [G44.3,65.8 Elwynn Forest]
[O]At [TAR951 Brother Paxton] in Northshire Abbey (a 4-minute detour up the Northshire road), [QT344] [QA345 Ink Supplies] (485 XP each; Foreman Oslow in Lakeshire takes 345 in chapter 16) [G49.6,40.4 Elwynn Forest]
[OC]Back to Stormwind by the same road
In the Mage Quarter at [TAR5694 High Sorcerer Andromath], [QA92489 Power Overwhelming] (3,950 XP, quest level 33, requires 24: done inside the City of Dalaran) - carry to 30-40 [G48.7,87.6 Stormwind City]
At [TAR297 Caretaker Folsom] at the cemetery, [QT70] [QA72 The Legend of Stalvan] (1,700 XP) [G42.5,72.4 Stormwind City]
Click the Sealed Crate beside him and take the Torn Journal Page [QT72] [QA74 The Legend of Stalvan] (to Marshal Haggard at the Eastvale Logging Camp, chapter 16) [G42.5,72.1 Stormwind City]
In the Park at [TAR5502 Shylamiir] (herbalism trainer), [QA92456 A Green Sample] (3,950 XP, quest level 33, requires 24: done inside the City of Dalaran) - carry to 30-40 [G31.5,62.6 Stormwind City]
[OC]|cffffcc00City of Dalaran:|r carry both to the City of Dalaran run (30-40 guide) - the other two, Starving Arcane and Heart of Disruption, come from the Image of Archmage Modera on the Silverpine shore 68.6,45.2 when you go
In the Keep at [TAR7766 Tyrion], [QT2746] [QA434 The Attack!] [G73.2,35.6 Stormwind City]
[OC]|cffffcc00The Attack!|r  -  Lord Gregor Lescovar (31) and Marzon the Silent Blade (30) talk in the garden beside Tyrion, then it is a fight: stand in the garden until the talk is over (the quest says so), then kill both together. They are not elite in the DB but level 30-31, so fight as a pair and do not split them. This is a kill quest, not an escort
Wait in the garden until their talk ends, then kill [TAR1754 Lord Gregor Lescovar] and [TAR1755 Marzon the Silent Blade] [QC434] [G72.4,35.1 Stormwind City]
At [TAR482 Elling Trias], [QT434] [QA394 The Head of the Beast] (1,900 XP) [G66.0,74.1 Stormwind City]
At [TAR332 Master Mathias Shaw], [QT394] [QA395 Brotherhood's End] [G78.3,70.7 Stormwind City]
At [TAR1646 Baros Alexston], [QT395] [QA396 An Audience with the King] [G57.7,47.9 Stormwind City]
In the Keep at [TAR1749 Lady Katrana Prestor], [QT396] (3,750 XP) [G80.1,38.2 Stormwind City]
[OC]|cffffcc00Gear (396):|r Seal of Wrynn (ring +3 Str +3 Agi +4 Sta +4 Int +3 Spi, unique) - a ring upgrade, wear it
[OC]|cffffcc00Carried on:|r 386 and 377 are complete (Lakeshire, chapter 16; Darkshire, chapter 17); 74 goes to Eastvale (chapter 16); 98219 to Southshore (chapter 23); optional 345 to Lakeshire (chapter 16) and 538 to Southshore (chapter 23); the Gnomeregan four - 2922, 2927, 2929 and 2928 - wait for chapters 24 and 25; the Dalaran lead-ins 92456 and 92489 ride on into the 30-40 guide
[OC]|cffffcc00Check:|r log should hold What Comes Around... (386), Crime and Punishment (377), The Legend of Stalvan (74), The Shamed Lieutenant (98219) and the Gnomeregan carries above, plus the older carries from chapters 10-14. Level 27 is close or reached. Next: fly to Lakeshire
[NX 26-27 Redridge and Eastvale]
]], "Forever Druid 1-30")
