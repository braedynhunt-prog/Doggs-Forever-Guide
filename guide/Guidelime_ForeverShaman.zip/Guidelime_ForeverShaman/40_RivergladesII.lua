Guidelime.registerGuide([[
[N 40-41 Riverglades]
[D Forever Shaman 30-60 (Braedyn)\\Back in the Riverglades at 40: Bolder'ok and Dunston's escape, the Twilight's Shroud with Sergeant Riftan, the chapel's water trouble, and Ghostmaw if you have the help. Ends at Farholde Keep, ready for Powderfuse Port.]
[GA Alliance]
[OC]|cffffffffLevel 40|r  -  this chapter wants level 40: Riftan's and Dunston's quests need 38 but are level 42-44, the Shroud's Corrupters are 42 and its Champions 44, the Bolder'ok ogres 41 with Chub'chob (45 elite) and Clugfist (50 elite) beside Gronok. Under 40, finish the level-40 block first
[OC]|cffffffffFarholde Keep|r  -  you arrive by hearth from Uldaman (chapter 39e); hearth = Farholde Keep and it stays there. A short clean-up: 11 plain quests, about 30,120 quest XP and 30s, every kill target a normal mob (the elites are named below: keep clear). Mounted if you bought the ram in chapter 39d; every leg works on foot. Mail counts from here: the Verger Greaves from chapter 38 go on now
[OC]|cffffcc00Sources:|r as in chapter 38, most givers here are not linked in Questie: givers and hand-ins come from Wowhead's quest pages, and the points the DB lacks come from Wowhead's maps. No Riverglades quest has a prerequisite in the DB; chain orders follow Wowhead's series, unverified
[OC]|cffffcc00Carried in:|r The Riverglades Report (95315, from Captain Nials in chapter 39) and Saving Marshal Ryan (94887) only if the Field Marshal's Log dropped in chapter 38. A Few Furs for Friz (94928) and Stepped Out (95961), if you hold them, ride on to chapter 41
[OC]|cffffcc00Training:|r none here; you trained the level-40 ranks in chapter 39d

[OC]|cffffffffFarholde Keep pickups|r
At [TAR257558 Demar Brant], [QT95315] (285 XP, if you took it in chapter 39) [QA94886 The Western Front] (375 XP: find Sergeant Riftan by the Twilight's Shroud in the west) [G66.7,81.0 Riverglades]
At [TAR257591 Ashe Amberhall], [QA94907 A Small Favor] (3,750 XP: summon a Twilight's Thrall at a conduit in the Twilight's Shroud and capture it with Amberhall's Soulstone) [G66.7,81.1 Riverglades]
[OC]|cFFFF0000GROUP 2+|r |cffffcc00WANTED: Ghostmaw (95991):|r 4,300 XP, optional. Ghostmaw is a level-42 ELITE crocolisk in the Sunnyglade water. Take it only with a second player and only for the Crocskin Waders (leather legs, +8 Str +11 Sta +6 Spi): they beat Triprunner Dungarees and Southern Watch Leggings, but not Apprentice Sorcerer's Slacks, Doomcaller's Pants or the Bolder'ok Loincloth from Dunston below. Otherwise leave the poster
[O]|cFFFF0000GROUP 2+|r At the WANTED! poster by the gate (Wowhead's map), [QA95991 WANTED: Ghostmaw] (4,300 XP: Ghostmaw's Fang to Wheatley the stable master) [G65.6,80.9 Riverglades]
At [TAR262031 Sister Rowland] in the chapel, [QA96085 Upstream Contamination] (4,300 XP: find and kill whatever fouls the drinking water) [G61.7,83.3 Riverglades]
At [TAR263613 Brother Lowley], [QA96081 Wound Dressings] (1,550 XP: 20 Mageweave Cloth from the humanoids here and in chapter 38). Already holding 20? Hand them in on the spot; the hand-in line at the end then ticks itself [G65.4,79.1 Riverglades]
[OC]Mageweave is also First Aid's cloth: Lowley takes 20 of it

[OC]|cffffffffBolder'ok|r  -  north from Terral's Watch to the ogre camp (x64-77 y13-34; the ogres are 41). Rog'mar (Horde, level-55 guards and an elite wind rider master at 59.6,45.1) stands on the way: go round its east side
At [TAR259352 Watcher Cornelius], [QA96125 In Need of Relief] (360 XP: find Dunston Willis among the ogres in Bolder'ok) [G59.4,63.8 Riverglades]
[OC]|cFFFF0000Danger:|r Blademaster Kaijo, a level-42 elite, walks north of Rog'mar (57-58,37-40); Scoutmaster Vargas, a level-42 elite, stands on Bolder'ok's east edge (75,32-36); Komuk, a level-45 elite, holds the south edge of the camp (67-72,29-33). Keep clear of all three on the way to Dunston
At [TAR259057 Dunston Willis] at the north end of Bolder'ok, [QT96125] (360 XP) [QA96126 An Ogre's Captive] (3,750 XP: Gronok's Key from Gronok the Butcher) [G68.6,12.8 Riverglades]
[OC]|cFFFF0000Danger:|r Chub'chob (level-45 elite, 66,18-24) and Clugfist (level-50 elite, 64-65,15-19) stand within a few yards of Gronok: pull Gronok away to the south-east before you fight
Kill [TAR263749 Gronok the Butcher] (level 44, not elite) for Gronok's Key (~91% - one kill; if it does not drop, wait for one respawn) [QC96126] [G67.6,19.2 Riverglades]
At [TAR259057 Dunston Willis], [QT96126] (3,750 XP) [QA94927 Dunston Checks Out] (4,650 XP: help him break out of Bolder'ok, then report to Watcher Cornelius) [G68.6,12.8 Riverglades]
Help Dunston break out of Bolder'ok (an escort: his path and any ambushes are not in the data, unverified) [QC94927] [G68.6,12.8 Riverglades]
[OC][A Shaman] |cffffcc00Gear (94927, choice):|r take the Prisoner Handwraps (cloth hands, +12 Spi, +15 spell power) over your gloves. One exception: if your gloves are Traveled Gloves and your legs are still Southern Watch Leggings or Triprunner Dungarees, take the Bolder'ok Loincloth (cloth legs, +13 Spi, +9 spell damage) instead. Dunston's Ogre Duster is a one-handed mace: pass
At [TAR259352 Watcher Cornelius], [QT94927] (4,650 XP) [G59.4,63.8 Riverglades]

[OC]|cffffffffUpstream Contamination|r  -  the creature and its spot are not in the data. Start at the plains water where you filled the phial in chapter 38 and follow the water upstream; unverified
Find and kill the creature fouling the drinking water [QC96085] [G62.0,52.0 Riverglades]

[OC]|cffffffffThe Twilight's Shroud|r  -  west past Sunnyglade to Sergeant Riftan (Twilight cultists 42-44 in the Shroud, x27-36 y36-55)
[OC]|cFFFF0000Danger:|r Ghostmaw, a level-42 elite, roams the Sunnyglade water (47-54,42-57): keep clear unless you took the poster with a second player
[O]|cFFFF0000GROUP 2+|r Kill [TAR263380 Ghostmaw] in the Sunnyglade water for Ghostmaw's Fang (~82% - one kill only, then abandon; the DB's other spot is the north end of the water at 53.7,41.7) [QC95991] [G47.2,56.7 Riverglades]
At [TAR258023 Sergeant Riftan], [QT94886] (375 XP) [QA94888 No Soldier Left Behind] (3,750 XP: rescue 5 Farholde Scouts in the Shroud) [QA94889 Carving a Path] (3,750 XP: 8 Twilight Fanatics, 8 Twilight Corrupters and 8 Twilight Champions) [QA96015 A Miner Problem] (3,600 XP: 5 Ogre Miners and 5 Twilight Subjugators in the cave near the Shroud) [G30.4,49.0 Riverglades]
[OC]|cFFFF0000Danger:|r Overlord Kilgar, a level-46 elite, holds the west end of the Shroud (26-27,43-45 on Wowhead's map): keep clear
Kill [TAR256795 Twilight Fanatic], [TAR256797 Twilight Corrupter] (42) and [TAR256799 Twilight Champion] (44), 8 of each, in the Shroud [QC94889] [G29.3,45.7 Riverglades]
Kill [TAR256799 Twilight Champion] for 5 Twilight Keys (~44% - budget ~12 kills, 4 more than Carving a Path needs) [QC94888] [G29.3,45.7 Riverglades]
Free 5 captive [TAR257926 Farholde Scout] in the Shroud with the Twilight Keys (where the captives stand and how the key frees them are not in the data; if no captive scouts stand in the Shroud, look along the river at 44,64) [QC94888] [G29.3,45.7 Riverglades]
Summon a [TAR258652 Twilight Thrall] at a conduit in the Shroud and capture it with Amberhall's Soulstone (the conduits are not in the data, unverified) [QC94907] [G29.3,45.7 Riverglades]
[OC]|cffffcc00Field Marshal's Log:|r the next line is yours only if the Log dropped in chapter 38 and you carry Saving Marshal Ryan (94887); otherwise skip it. Ryan stands 3-4 units north of Kilgar: approach from the east
[O]Only if you carry 94887: at [TAR257250 Marshal Ryan] (Wowhead's map), [QT94887] (2,100 XP) [QA94892 Dying Wish] (4,200 XP: his crest to Demar Brant) [G26.2,40.4 Riverglades]
Kill 5 [TAR260995 Ogre Miner] and 5 [TAR260996 Twilight Subjugator] in the cave near the Shroud (the DB puts them at 27.7,36.7, north of the cultists; the entrance and their levels are not in the data, and Crag'rog (28-30,36-37) is unknown) [QC96015] [G27.7,36.7 Riverglades]
[OC][A Shaman] |cffffcc00Gear (96015):|r the Twilight Mine Light (cloth head, +12 Sta, +13 spell power, +4 Mining) is below your Saltseer's Helm or Wild Headdress: vendor it (50s 18c)
At [TAR258023 Sergeant Riftan], [QT94888] (3,750 XP) [QT94889] (3,750 XP + 30s) [QT96015] (3,600 XP) [G30.4,49.0 Riverglades]

[OC]|cffffffffBack to Farholde Keep|r
|cFFfff8a3Hearth to [H Farholde Keep]|r (on cooldown? ride back east past Sunnyglade and Wheeler's Grange) [G30.4,49.0 Riverglades]
At [TAR257591 Ashe Amberhall], [QT94907] (3,750 XP) [G66.7,81.1 Riverglades]
[O]Only if you carry 94892: at [TAR257558 Demar Brant], [QT94892] (4,200 XP). He then offers Delivering Closure, a delivery to Stormwind: leave it for the 40-50 guide's first Stormwind visit [G66.7,81.0 Riverglades]
[O]|cFFFF0000GROUP 2+|r At [TAR259859 Wheatley], the stable master, [QT95991] (4,300 XP) [G63.7,84.8 Riverglades]
[OC][A Shaman] |cffffcc00Gear (95991):|r put on the Crocskin Waders if your legs are Triprunner Dungarees or Southern Watch Leggings; otherwise vendor them
[OC][A Shaman] |cffffcc00Gear (96085):|r the Superior Healing Potion is fixed: keep it
At [TAR262031 Sister Rowland], [QT96085] (4,300 XP) [G61.7,83.3 Riverglades]
At [TAR263613 Brother Lowley], [QT96081] (1,550 XP) [G65.4,79.1 Riverglades]
[OC]|cffffcc00Gold check:|r this chapter's quests pay 30s in all (Carving a Path)
[OC]|cffffcc00Check:|r handed in here: The Riverglades Report (95315), The Western Front (94886), A Small Favor (94907), Upstream Contamination (96085), Wound Dressings (96081), In Need of Relief (96125), An Ogre's Captive (96126), Dunston Checks Out (94927), No Soldier Left Behind (94888), Carving a Path (94889), A Miner Problem (96015), and if taken WANTED: Ghostmaw (95991), Saving Marshal Ryan (94887) and Dying Wish (94892). In the log from chapters 38-40, only if taken: A Few Furs for Friz (94928) and Stepped Out (95961) for Powderfuse Port in chapter 41. Delivering Closure (94893) is left untaken for the 40-50 guide. Hearth = Farholde Keep
[OC]|cffffffffNext|r  -  Powderfuse Port on the east coast (chapter 41), from Farholde Keep

[NX 41-42 Powderfuse Port]
]], "Forever Shaman 30-60")
